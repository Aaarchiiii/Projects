-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 19, 2023 at 06:45 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eshopdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `contactus`
--

CREATE TABLE `contactus` (
  `qid` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(40) NOT NULL,
  `phone_no` bigint(20) NOT NULL,
  `message` varchar(500) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contactus`
--

INSERT INTO `contactus` (`qid`, `name`, `email`, `phone_no`, `message`, `date`) VALUES
(3, 'Ruchi Agarwal', 'ruchiagra5@gmail.com', 8126027351, 'I am facing problems.', '2023-07-08');

-- --------------------------------------------------------

--
-- Table structure for table `mobilespecification`
--

CREATE TABLE `mobilespecification` (
  `Pid` int(11) NOT NULL,
  `Os` varchar(30) DEFAULT NULL,
  `Processor` varchar(30) DEFAULT NULL,
  `Color` varchar(30) DEFAULT NULL,
  `SIM_Type` varchar(30) DEFAULT NULL,
  `Hybrid_Sim_Slot` tinyint(1) DEFAULT NULL,
  `Display_size` varchar(30) DEFAULT NULL,
  `Resolution` varchar(30) DEFAULT NULL,
  `Internal_Storage` varchar(10) DEFAULT NULL,
  `RAM` varchar(10) DEFAULT NULL,
  `Primary_Camera` varchar(30) DEFAULT NULL,
  `Secondary_Camera` varchar(30) DEFAULT NULL,
  `Network_Type` varchar(30) DEFAULT NULL,
  `Battery_Capacity` varchar(30) DEFAULT NULL,
  `Width` varchar(10) DEFAULT NULL,
  `Height` varchar(10) DEFAULT NULL,
  `Warranty_Summary` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mobilespecification`
--

INSERT INTO `mobilespecification` (`Pid`, `Os`, `Processor`, `Color`, `SIM_Type`, `Hybrid_Sim_Slot`, `Display_size`, `Resolution`, `Internal_Storage`, `RAM`, `Primary_Camera`, `Secondary_Camera`, `Network_Type`, `Battery_Capacity`, `Width`, `Height`, `Warranty_Summary`) VALUES
(1006, 'Android 8.1', '4g', 'black', 'dual sim', 0, '5.4 inches', '250px', '16 GB', '1 GB', '5 MP', '2 MP', '4g', '2500 mAh', '7 cm', '15 cm', '6 months');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `pid` varchar(100) DEFAULT NULL,
  `order_date` date DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `Payment_status` varchar(50) DEFAULT NULL,
  `status` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `user_id`, `pid`, `order_date`, `amount`, `address`, `Payment_status`, `status`) VALUES
(1, 13, '1003,1006', '2023-07-18', 31479, 'Archi Agarwal,18/4 nagla ganga ram near Agrasen bhavan\r\nLohamandi Shahganj road', 'Cash On Delivery', 'Delivered');

-- --------------------------------------------------------

--
-- Table structure for table `productmaster`
--

CREATE TABLE `productmaster` (
  `Pid` int(11) NOT NULL,
  `Pname` varchar(40) DEFAULT NULL,
  `Pprice` int(11) DEFAULT NULL,
  `Ptype` varchar(40) DEFAULT NULL,
  `Pimage` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `productmaster`
--

INSERT INTO `productmaster` (`Pid`, `Pname`, `Pprice`, `Ptype`, `Pimage`) VALUES
(1002, 'DR2 TV 32 Inch Smart LED TV 1GB/8GB', 16999, 'TV', 'product/151229935-111471535-1602927019.jpg'),
(1003, 'Intex 3201SMT 31.5 inches(80 cm) Smart H', 21890, 'TV', 'product/133187845-77639229-1516084524.jpg'),
(1004, 'iBPL GENERIC 32 INCHES LED SMART TV', 11900, 'TV', 'product/151481911-112088478-1606742804.jpg'),
(1006, 'Redmi 9A 2GB 32GB (Sea Blue)', 9589, 'Mobile', 'product/152862795-115760679-1637983476.jpg'),
(1007, 'Realme Narzo 50i (Carbon Black, 32 GB) (', 8399, 'Mobile', 'product/153337756-117025319-1678737501.jpg'),
(1008, '(Refurbished) Samsung S20 (12GB RAM, 128', 27989, 'Mobile', 'product/153368861-117128817-1683178130.jpg'),
(1009, 'TCL (32S5202) 81 cm (32 inch) HD Ready S', 15779, 'TV', 'product/152852749-115734989-1637233799.jpg'),
(1010, 'BPL GENERIC 32 INCHES LED TV WITH WARRAN', 11000, 'TV', 'product/152800810-115590233-1653670460.jpg'),
(1011, 'I-Smart I1 Giant 6.4 inches(16.26 cm) 3G', 8999, 'Mobile', 'product/p9.jpg.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tv_specification`
--

CREATE TABLE `tv_specification` (
  `Pid` int(11) NOT NULL,
  `In_The_Box` varchar(150) DEFAULT NULL,
  `color` varchar(20) DEFAULT NULL,
  `Display_Size` varchar(20) DEFAULT NULL,
  `Screen_Type` varchar(20) DEFAULT NULL,
  `HD_Tech_Res` varchar(20) DEFAULT NULL,
  `Smart_Tv` tinyint(1) DEFAULT NULL,
  `Motion_Sensor` tinyint(1) DEFAULT NULL,
  `HDMI` varchar(20) DEFAULT NULL,
  `USB` varchar(20) DEFAULT NULL,
  `Built_In_WiFi` tinyint(1) DEFAULT NULL,
  `Launch_Year` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tv_specification`
--

INSERT INTO `tv_specification` (`Pid`, `In_The_Box`, `color`, `Display_Size`, `Screen_Type`, `HD_Tech_Res`, `Smart_Tv`, `Motion_Sensor`, `HDMI`, `USB`, `Built_In_WiFi`, `Launch_Year`) VALUES
(1002, '1number LED Tv, 1Number Power Cord, 2Number Batteries AAA Size, 1Number Remocon, 1Number Stand left, 1Number stand Right', 'black', '55 inches(139.7cm)', 'LED', '4K Ultra HD', 0, 0, '3', '2', 0, 2010),
(1003, '1number LED Tv, 1Number Power Cord, 2Number Battery', 'blue', '65 inches', 'LED', '5K Ultra HD', 0, 0, '2', '3', 0, 2012),
(1004, '1number LED Tv, 1Number Power Cord, 2Number Batteries AAA Size, 1Number Remocon, 1Number Stand left, 1Number stand Right', 'black', '65 inches', 'LED', '5K Ultra HD', 0, 0, '3', '2', 0, 2016);

-- --------------------------------------------------------

--
-- Table structure for table `usermaster`
--

CREATE TABLE `usermaster` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(40) DEFAULT NULL,
  `user_email` varchar(40) DEFAULT NULL,
  `user_pwd` varchar(40) DEFAULT NULL,
  `user_gender` varchar(40) DEFAULT NULL,
  `user_mobile` bigint(20) DEFAULT NULL,
  `user_dob` date DEFAULT NULL,
  `Role` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `usermaster`
--

INSERT INTO `usermaster` (`user_id`, `user_name`, `user_email`, `user_pwd`, `user_gender`, `user_mobile`, `user_dob`, `Role`) VALUES
(7, 'Pragun Bansal', 'pragunbansal885@gmail.com', '24052010', 'Male', 9837098372, '2010-05-24', 'client'),
(9, 'anushka agarwal', 'anushkaa794@gmail.com', 'anushka', 'Female', 6396642576, '2005-06-02', 'client'),
(10, 'Ruchi Agarwal', 'ruchiagra5@gmail.com', '12345', 'Female', 8126027351, '1982-10-10', 'Client'),
(23, 'Archi Agarwal', 'archiagarwal23@gmail.com', 'archi14', 'Female', 8126293680, '2023-07-13', 'Admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contactus`
--
ALTER TABLE `contactus`
  ADD PRIMARY KEY (`qid`);

--
-- Indexes for table `mobilespecification`
--
ALTER TABLE `mobilespecification`
  ADD PRIMARY KEY (`Pid`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `productmaster`
--
ALTER TABLE `productmaster`
  ADD PRIMARY KEY (`Pid`);

--
-- Indexes for table `tv_specification`
--
ALTER TABLE `tv_specification`
  ADD PRIMARY KEY (`Pid`);

--
-- Indexes for table `usermaster`
--
ALTER TABLE `usermaster`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `user_email` (`user_email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contactus`
--
ALTER TABLE `contactus`
  MODIFY `qid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `usermaster`
--
ALTER TABLE `usermaster`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
